/* Desafio 11 >>> Verificar porque não está passando

function generatePhoneNumber(number) {
    if(number.length !== 11) {
      return 'Array com tamanho incorreto.';
    }
    novoNum = [];
    let countOccurrences = (number, val) => number.reduce((a, v) => (v === val ? a + 1 : a), 0);

    for(let i = 0; i < number.length; i += 1) {
      if(number[i] < 0 || number[i] > 9) {
        return 'Não é possível gerar um numero de telefone com esses valores.';
      }
      else if(countOccurrences(number, number[i]) >= 3) {
        return 'Não é possível gerar um numero de telefone com esses valores.';
      }
      else {
        return novoNum;
      }
    }
}
*/


// let phone = '(';
//   phone = phone + arr11[0] + arr11[1] + ')' + arr11[2] + arr11[3] + arr11[4] + arr11[5] + arr11[6] + '-' + arr11[7] + arr11[8] +   arr11[9] + arr11[10];
//       console.log(phone);

//      if(arr11.length !== 11) {
//        phone = 'Array com tamanho incorreto.'

//          for(let i in arr11) {
//            let arr11a = arr11.sort();

//         //  for(let i = 0; i < arr11a.length; i += 1) {
//         //      if(arr11a[i] < 0 || arr11a[i] > 9) {

//         if(arr11a[i] < 0 || (arr11a[i] > 9) || ((arr11a[i] === arr11a[i]+1 && arr11a[i] === arr11a[i]+2))) {
//          phone = 'não é possível gerar um numero de telefone esses valores.';
//         }
//         // else {
//         //   console.log(arr11a);
//         }
//       }
//       return phone;


// console.log(generatePhoneNumber([0,1,9,3,6,5,4,7,8,2]));

